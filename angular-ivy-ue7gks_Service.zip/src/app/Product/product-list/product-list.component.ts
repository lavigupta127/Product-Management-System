import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Product } from '../product';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})

export class ProductListComponent implements OnInit {

  products = [] ;
  searchTerm: string ;
  hideImageButton: HTMLElement ;
  showImageButton: HTMLElement ;
  showImage = false ;

  constructor(private productService: ProductService, private router: Router) { }

  ngOnInit() {

    this.hideImageButton = document.getElementById('hideImage') ;
    this.showImageButton = document.getElementById('showImage') ;
   
    this.hideImageButton.style.display = 'none' ;

    this.productService.getProducts().subscribe(
      data => {this.products = data ;
    
    });
    
  }

  hideImages() {
     this.hideImageButton.style.display = 'none' ;
    this.showImageButton.style.display = 'initial' ;
    this.showImage = false ;

  }

  showImages() {
     this.hideImageButton.style.display = 'initial' ;
    this.showImageButton.style.display = 'none' ;
    this.showImage = true ;

  }
  
  editRow(rowIndex: number) {
    this.router.navigate(['/save-product', rowIndex]) ;
  
  }
}