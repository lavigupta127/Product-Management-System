import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../product.service';
import { Product } from '../../Product/product';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})

export class ProductDetailsComponent implements OnInit {

  productId: number ;
  product: Product ;
  index: number ;


  constructor(private route: ActivatedRoute, private productService: ProductService, private router: Router) { }

  ngOnInit() {
    this.productId = parseInt(this.route.snapshot.paramMap.get('id'));
    
    this.productService.getProductById(this.productId).subscribe(
    data => this.product = data,
    err => console.error(err)
    ); 
    
  
  }

  productNotFound() {
    if(this.product) {
      return false ;
    }
    else
    return true ;
  }

  back() {
    this.router.navigate(['/products']) ;
  }

  edit() {
    this.productService.getIndexById(this.productId).subscribe(
      data => this.index = data
    ) ;
    
    this.router.navigate(['/save-product', this.index]) ;
  }

}