import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductListComponent } from '../product-list/product-list.component';
import { ProductService } from '../product.service';
import { HttpClientModule } from '@angular/common/http';
import { ProductDetailsComponent } from '../product-details/product-details.component';
import { AppRoutingModule } from '../../app-routing/app-routing.module';
import { ProductFilterPipe } from '../product-filter.pipe';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { SaveProductComponent } from '../save-product/save-product.component';

@NgModule({
  imports: [
    CommonModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [ProductListComponent, ProductDetailsComponent, ProductFilterPipe, SaveProductComponent],
  providers: [ProductService],
  exports: [ProductListComponent, ProductDetailsComponent, SaveProductComponent]
})
export class ProductModule { }