import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Product } from '../../Product/product';
import { Router, ActivatedRoute } from '@angular/router';
import { ProductService } from '../../Product/product.service';

@Component({
  selector: 'app-save-product',
  templateUrl: './save-product.component.html',
  styleUrls: ['./save-product.component.css']
})
export class SaveProductComponent implements OnInit {

  formGroup: FormGroup ;
  product = <Product>{} ;
  products = [] ;
  id: number ;
  index: number ;
  flag = true ;
  rowIndex = -1 ;
  editProduct = <Product>{} ;
  deleteConfirmation: boolean ;

  constructor(private formBuilder: FormBuilder, private router: Router, private productService: ProductService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.rowIndex = parseInt(this.route.snapshot.paramMap.get('id')) ;
    
    this.formGroup = this.formBuilder.group({
      productName: ['', Validators.required],
      productCode: ['', Validators.required],
      availabilityDate: [''],
      price: ['', Validators.pattern(/^[0-9]+([.][0-9]+)?$/)],
      starRating: ['', Validators.compose([Validators.min(1), Validators.max(5), Validators.pattern(/^[0-9]+([.][0-9]+)?$/)])],
      description: [''],
      productImage: ['']
    }) ;

    this.productService.getProducts().subscribe(
      data => this.products = data
    );

    if(this.rowIndex !== -1) {
      this.editProduct = this.products[this.rowIndex] ;
    }

    this.formGroup.controls.productName.patchValue(this.editProduct.productName) ;
    this.formGroup.controls.productCode.patchValue(this.editProduct.productCode) ;
    this.formGroup.controls.availabilityDate.patchValue(this.editProduct.availabilityDate) ;
    this.formGroup.controls.price.patchValue(this.editProduct.price) ;
    this.formGroup.controls.starRating.patchValue(this.editProduct.starRating) ;
    this.formGroup.controls.description.patchValue(this.editProduct.description) ;
    this.formGroup.controls.productImage.patchValue(this.editProduct.productImage) ;
    

  }

  generateId(): number {
    
    while(this.flag) {
      this.id = Math.floor(Math.random()*100000000000000000) ;
      this.flag = false ;
      for(this.index=0; this.index< this.products.length; this.index ++) {
        if(this.id === this.products[this.index].productId){
          this.flag = true ;
          break ;
        }
      }
    }
    return this.id ;
  }

  saveProduct() {
    this.product.productId = this.generateId() ;
    this.product.productName = this.formGroup.value.productName ;
    this.product.productCode = this.formGroup.value.productCode ;
    this.product.availabilityDate = this.formGroup.value.availabilityDate ;
    this.product.price = this.formGroup.value.price ;
    this.product.starRating = this.formGroup.value.starRating ;
    this.product.description = this.formGroup.value.description ;
    this.product.productImage = this.formGroup.value.productImage ;

    if(this.rowIndex === -1) {
      this.productService.addProduct(this.product).subscribe() ;
    }
    else {
    
      this.productService.editProduct(this.product, this.rowIndex).subscribe() ;

    }
    this.router.navigate(['/products']) ;
  
  }

  cancel() {
    this.router.navigate(['/products']) ;
  }

  delete() {
    if(this.rowIndex !== -1) {
      this.deleteConfirmation = confirm('Are you sure you want to delete this ?') ;
      if(this.deleteConfirmation) {
        this.productService.deleteProduct(this.rowIndex).subscribe(
         data => this.products = data
        );
        this.router.navigate(['/products']) ;
      }
    }
    else {
      this.router.navigate(['/products']) ;
    }
  }

}