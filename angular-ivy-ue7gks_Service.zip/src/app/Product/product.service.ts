import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http' ;
import { Observable, of, BehaviorSubject } from 'rxjs';
import { Product } from '../Product/product';
import { map } from 'rxjs/operators' ;

@Injectable()
export class ProductService  {

  productUrl = 'assets/products.json' ;
  products = [] ;
  index: number ;


  constructor(private http: HttpClient) {
   this.readProducts().subscribe(
      data => this.products = data
    );
   }

   readProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(this.productUrl) ;

  }

  getProducts(): Observable<Product[]> {
    if(this.products.length === 0){
      return this.readProducts() ;
    }
    return of(this.products) ;
  }

  getProductById( id: number): Observable<Product> {
    return this.getProducts().pipe(map(products => products.find(product => product.productId === id))) ;
  }

  addProduct(product: Product): Observable<Product[]> {
    this.products.push(product) ;
    return of(this.products) ;
  }

  editProduct(product: Product, index: number): Observable<Product[]> {
    this.products[index] = product ;
    return of(this.products) ;
  }

  deleteProduct(index: number): Observable<Product[]> {
    this.products.splice(index, 1) ;
    return of(this.products) ;
  }

  getIndexById(id: number): Observable<number> {
    for(this.index = 0; this.index<this.products.length; this.index ++) {
      if(id === this.products[this.index].productId) {
        return of(this.index) ;
      }
    }
  }

}