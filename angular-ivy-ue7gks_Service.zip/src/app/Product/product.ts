export interface Product {
  productId: number ;
  productName: string ;
  productCode: string ;
  availabilityDate: string ;
  description: string ;
  price: number ;
  starRating: number ;
  productImage: string ;
}